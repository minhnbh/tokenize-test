import React from "react";
import "./App.css";
import TradingView from "./TradingView";

function App() {
  return (
    <div className="App">
      <TradingView />
      {/* <div className="triangle">
        <div className="select-interval-container">
          
        </div>
      </div> */}
    </div>
  );
}

export default App;
